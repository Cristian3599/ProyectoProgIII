import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecurityService } from 'src/app/services/security.service';
import { Router } from '@angular/router';
import { ReCaptchaValidator } from 'src/app/helpers/validators/re-captcha.validator';

declare var openPlatformModalMessage: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  fgValidation: FormGroup;

  constructor(private fb: FormBuilder, private secService: SecurityService, private router: Router) { }

  resolved(captchaResponse: string) {
    if (captchaResponse.length != 0){
      console.log(`Resolved captcha with response: ${captchaResponse}`);
      return true;
    }else {
      return false;
    }
  }

  fgValidationBuilder(){
    this.fgValidation = this.fb.group({
      username: ['administrator@gmail.com', [Validators.required, Validators.minLength(5), Validators.maxLength(30), Validators.email]],
      password: ['12345', [Validators.required, Validators.minLength(5), Validators.maxLength(15), Validators.pattern("")]],
      recaptchaReactive: ['', [Validators.required]]
    });
  }

  loginEvent(){
    if(this.fgValidation.invalid){
      openPlatformModalMessage("Invalid data!");
    }else {
      let u = this.fg.username.value;
      let p = this.fg.password.value;
      let user = this.secService.loginUser(u, p);
      if(user != null){
        console.log(user);
        this.router.navigate(['/home']);
      }else {
        openPlatformModalMessage("The data is invalid!")
      }
    }
  }

  get fg(){
    return this.fgValidation.controls;
  }

  ngOnInit() {
    this.fgValidationBuilder();
  }

}
